return {
  "mfussenegger/nvim-lint",
  opts = {
    linters_by_ft = {
      javascript = { "eslint_d_custom" },
      typescript = { "eslint_d_custom" },
      vue = { "eslint_d_custom" },
    },
  },
  config = function(_, opts)
    local lint = require("lint")

    lint.linters_by_ft = opts.linters_by_ft

    -- 1. Get the default eslint_d config so we can reuse its parser
    local eslint = lint.linters.eslint_d

    -- 2. Create the custom linter
    lint.linters.eslint_d_custom = vim.tbl_deep_extend("force", eslint, {
      -- CRITICAL FIX 1: Ensure JSON output is requested so nvim-lint can parse it
      args = {
        "--format",
        "json",
        "--stdin",
        "--stdin-filename",
        function()
          return vim.api.nvim_buf_get_name(0)
        end,
      },
      -- CRITICAL FIX 2: Dynamic CWD (Current Working Directory)
      -- This tells eslint_d to run from inside 'server/' when you are editing 'server/src/...'
      -- This fixes the "Unable to resolve path" errors.
      cwd = function(ctx)
        -- Find package.json starting from the current file's directory and going up
        local root = vim.fs.find("package.json", { path = ctx.filename, upward = true })[1]
        -- If found, use that directory; otherwise use the standard cwd
        return root and vim.fs.dirname(root) or vim.loop.cwd()
      end,
    })

    -- 3. Setup auto-triggering
    local lint_augroup = vim.api.nvim_create_augroup("lint", { clear = true })
    vim.api.nvim_create_autocmd({ "BufEnter", "BufWritePost", "InsertLeave" }, {
      group = lint_augroup,
      callback = function()
        lint.try_lint()
      end,
    })
  end,
}
